%CONTENTS GEOM2D Geometry 2D Toolbox.
% Version 1.24 07-Jun-2018.
