% CircStat Toolbox
%   Toolbox for circular statistics with Matlab
